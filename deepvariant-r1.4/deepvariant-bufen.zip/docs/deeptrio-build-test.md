## Building DeepTrio from sources

DeepTrio is a part of DeepVariant. DeepVariant comes with scripts to build it
from the source code. For more details please refer to
["Building DeepVariant from sources"](deepvariant-build-test.md)
